/* ===========================
   ShopEase - Cart Page JS
   =========================== */

const COUPONS = {
  SAVE10:   { type: 'percent', value: 10,  label: '10% off'  },
  SUMMER20: { type: 'percent', value: 20,  label: '20% off'  },
  FLAT15:   { type: 'flat',    value: 15,  label: '$15 off'  },
};

let appliedCoupon = null;

// ===== RENDER CART =====
function renderCart() {
  const cart       = getCart();
  const listEl     = document.getElementById('cartItemsList');
  const layoutEl   = document.getElementById('cartLayout');
  const emptyEl    = document.getElementById('emptyCart');
  const suggestEl  = document.getElementById('suggestionsSection');
  const countEl    = document.getElementById('cartItemsCount');

  if (!listEl) return;

  const totalItems = cart.reduce((s, i) => s + i.qty, 0);
  countEl && (countEl.textContent = `${totalItems} item${totalItems !== 1 ? 's' : ''}`);

  if (cart.length === 0) {
    layoutEl?.classList.add('hidden');
    emptyEl?.classList.remove('hidden');
    renderSuggestions();
    return;
  }

  layoutEl?.classList.remove('hidden');
  emptyEl?.classList.add('hidden');

  listEl.innerHTML = cart.map(item => {
    const p = PRODUCTS_EXTENDED.find(p => p.id === item.id);
    if (!p) return '';
    return `
      <div class="cart-item" id="cart-item-${p.id}" data-id="${p.id}">
        <img class="cart-item-img" src="${p.image}" alt="${p.title}"
          onclick="window.location='product-details.html?id=${p.id}'"
          style="cursor:pointer;"
          onerror="this.src='https://via.placeholder.com/90?text=?'" />
        <div class="cart-item-body">
          <div class="cart-item-category">${p.category}</div>
          <div class="cart-item-title"
            onclick="window.location='product-details.html?id=${p.id}'"
            style="cursor:pointer;">${p.title}</div>
          <div class="cart-item-unit">${formatPrice(p.price)} / unit</div>
          <!-- Mobile controls -->
          <div style="display:flex; align-items:center; gap:0.75rem; margin-top:0.5rem; display:none;" class="mobile-item-controls">
            <div class="item-qty-control">
              <button class="item-qty-btn" onclick="changeItemQty(${p.id}, -1)">−</button>
              <span class="item-qty-num">${item.qty}</span>
              <button class="item-qty-btn" onclick="changeItemQty(${p.id}, 1)">+</button>
            </div>
            <span style="font-weight:800; background:var(--gradient); -webkit-background-clip:text; -webkit-text-fill-color:transparent;">${formatPrice(p.price * item.qty)}</span>
          </div>
        </div>
        <div class="cart-item-controls">
          <span class="cart-item-price">${formatPrice(p.price * item.qty)}</span>
          <div class="item-qty-control">
            <button class="item-qty-btn" onclick="changeItemQty(${p.id}, -1)">−</button>
            <span class="item-qty-num">${item.qty}</span>
            <button class="item-qty-btn" onclick="changeItemQty(${p.id}, 1)">+</button>
          </div>
          <button class="remove-btn" onclick="removeItem(${p.id})" aria-label="Remove item">🗑️</button>
        </div>
      </div>
    `;
  }).join('');

  updateSummary();
  renderSuggestions();
}

function changeItemQty(productId, delta) {
  const cart = getCart();
  const item = cart.find(i => i.id === productId);
  if (!item) return;

  const newQty = item.qty + delta;
  if (newQty < 1) {
    removeItem(productId);
    return;
  }
  updateCartQty(productId, newQty);
  renderCart();
}

function removeItem(productId) {
  const el = document.getElementById(`cart-item-${productId}`);
  if (el) {
    el.classList.add('removing');
    setTimeout(() => {
      removeFromCart(productId);
      renderCart();
    }, 300);
  } else {
    removeFromCart(productId);
    renderCart();
  }
  const p = PRODUCTS_EXTENDED.find(p => p.id === productId);
  if (p) showToast(`"${p.title}" removed from cart`, 'info');
}

// ===== ORDER SUMMARY =====
function updateSummary() {
  const cart     = getCart();
  const subtotal = cart.reduce((s, i) => {
    const p = PRODUCTS_EXTENDED.find(p => p.id === i.id);
    return s + (p ? p.price * i.qty : 0);
  }, 0);

  const shipping = subtotal >= 50 ? 0 : 5.99;
  const tax      = subtotal * 0.08;
  let discount   = 0;

  if (appliedCoupon) {
    const c = COUPONS[appliedCoupon];
    discount = c.type === 'percent'
      ? subtotal * c.value / 100
      : Math.min(c.value, subtotal);
  }

  const total = Math.max(0, subtotal - discount + shipping + tax);

  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
  set('summarySubtotal', formatPrice(subtotal));
  set('summaryShipping', shipping === 0 ? 'FREE 🎉' : formatPrice(shipping));
  set('summaryTax',      formatPrice(tax));
  set('summaryTotal',    formatPrice(total));

  const discountRow = document.getElementById('discountRow');
  if (discountRow) {
    discountRow.style.display = discount > 0 ? 'flex' : 'none';
    set('summaryDiscount', `-${formatPrice(discount)}`);
  }
}

// ===== COUPON =====
document.getElementById('applyCoupon')?.addEventListener('click', () => {
  const input = document.getElementById('couponInput');
  const code  = input?.value.trim().toUpperCase();

  if (!code) { showToast('Please enter a coupon code', 'warning'); return; }

  if (COUPONS[code]) {
    appliedCoupon = code;
    showToast(`Coupon "${code}" applied! ${COUPONS[code].label} discount added 🎉`, 'success');
    updateSummary();
    input.value = '';
    input.style.borderColor = 'var(--success)';
    setTimeout(() => input.style.borderColor = '', 2000);
  } else {
    showToast(`Invalid coupon code "${code}"`, 'error');
    input.style.borderColor = 'var(--danger)';
    setTimeout(() => input.style.borderColor = '', 2000);
  }
});

// ===== CLEAR CART =====
document.getElementById('clearCartBtn')?.addEventListener('click', () => {
  if (getCart().length === 0) return;
  localStorage.removeItem('shopease-cart');
  updateCartUI();
  renderCart();
  showToast('Cart cleared', 'info');
});

// ===== CHECKOUT =====
document.getElementById('checkoutBtn')?.addEventListener('click', () => {
  const cart = getCart();
  if (cart.length === 0) {
    showToast('Your cart is empty!', 'warning');
    return;
  }
  // Show success modal
  const orderNum = Math.floor(100000 + Math.random() * 900000);
  document.getElementById('orderNumber').textContent = orderNum;
  document.getElementById('checkoutModal')?.classList.remove('hidden');
});

document.getElementById('modalContinue')?.addEventListener('click', () => {
  // Clear cart and redirect
  localStorage.removeItem('shopease-cart');
  updateCartUI();
  window.location.href = 'products.html';
});

// Close modal on overlay click
document.getElementById('checkoutModal')?.addEventListener('click', (e) => {
  if (e.target === e.currentTarget) {
    e.currentTarget.classList.add('hidden');
  }
});

// ===== SUGGESTIONS =====
function renderSuggestions() {
  const grid = document.getElementById('suggestionsGrid');
  if (!grid) return;
  const cartIds = getCart().map(i => i.id);
  const suggestions = PRODUCTS_EXTENDED
    .filter(p => !cartIds.includes(p.id))
    .sort(() => Math.random() - 0.5)
    .slice(0, 4);
  grid.innerHTML = suggestions.map(p => buildProductCard(p)).join('');
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  renderCart();
});
