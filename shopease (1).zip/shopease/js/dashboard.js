/* ===========================
   ShopEase - Dashboard JS
   =========================== */

// ===== STAT COUNTER ANIMATION =====
function animateValue(el, target, prefix = '', duration = 1500) {
  let start     = 0;
  const step    = target / (duration / 16);
  const timer   = setInterval(() => {
    start = Math.min(start + step, target);
    const formatted = prefix === '$'
      ? prefix + Math.floor(start).toLocaleString()
      : Math.floor(start).toLocaleString();
    el.textContent = formatted;
    if (start >= target) clearInterval(timer);
  }, 16);
}

function initStatCounters() {
  document.querySelectorAll('.stat-value[data-target]').forEach(el => {
    const target = parseInt(el.dataset.target);
    const prefix = el.dataset.prefix || '';
    animateValue(el, target, prefix);
  });
}

// ===== SALES CHART (Pure Canvas) =====
let activeChartType = 'sales';

function drawChart(type = 'sales') {
  const canvas = document.getElementById('salesChart');
  if (!canvas) return;

  const ctx    = canvas.getContext('2d');
  const data   = MONTHLY_SALES;
  const values = data.map(d => type === 'sales' ? d.sales : d.orders);
  const labels = data.map(d => d.month);
  const maxVal = Math.max(...values) * 1.15;

  // Set canvas size
  const wrapper = canvas.parentElement;
  canvas.width  = wrapper.clientWidth  || 700;
  canvas.height = wrapper.clientHeight || 260;

  const W = canvas.width;
  const H = canvas.height;

  const padLeft   = 60;
  const padRight  = 20;
  const padTop    = 20;
  const padBottom = 40;
  const chartW    = W - padLeft - padRight;
  const chartH    = H - padTop - padBottom;

  ctx.clearRect(0, 0, W, H);

  // Theme colors
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  const gridColor  = isDark ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.06)';
  const textColor  = isDark ? 'rgba(255,255,255,0.5)'  : 'rgba(0,0,0,0.45)';
  const labelColor = isDark ? 'rgba(255,255,255,0.7)'  : 'rgba(0,0,0,0.65)';

  const numGridLines = 5;
  ctx.font      = '11px Inter, sans-serif';
  ctx.textAlign = 'right';
  ctx.fillStyle = textColor;

  // Grid lines + Y labels
  for (let i = 0; i <= numGridLines; i++) {
    const y   = padTop + chartH - (i / numGridLines) * chartH;
    const val = Math.round((maxVal * i) / numGridLines);
    ctx.strokeStyle = gridColor;
    ctx.lineWidth   = 1;
    ctx.beginPath();
    ctx.moveTo(padLeft, y);
    ctx.lineTo(padLeft + chartW, y);
    ctx.stroke();

    const label = type === 'sales'
      ? (val >= 1000 ? '$' + (val / 1000).toFixed(0) + 'k' : '$' + val)
      : (val >= 1000 ? (val / 1000).toFixed(0) + 'k' : String(val));
    ctx.fillStyle = textColor;
    ctx.fillText(label, padLeft - 8, y + 4);
  }

  // Points
  const points = values.map((v, i) => ({
    x: padLeft + (i / (values.length - 1)) * chartW,
    y: padTop + chartH - (v / maxVal) * chartH,
  }));

  // Gradient fill under line
  const grad = ctx.createLinearGradient(0, padTop, 0, padTop + chartH);
  grad.addColorStop(0,   'rgba(124, 58, 237, 0.35)');
  grad.addColorStop(0.6, 'rgba(59, 130, 246, 0.12)');
  grad.addColorStop(1,   'rgba(124, 58, 237, 0)');

  ctx.beginPath();
  ctx.moveTo(points[0].x, padTop + chartH);
  ctx.lineTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) {
    const cp = {
      x: (points[i - 1].x + points[i].x) / 2,
      y: (points[i - 1].y + points[i].y) / 2,
    };
    ctx.quadraticCurveTo(points[i - 1].x, points[i - 1].y, cp.x, cp.y);
  }
  ctx.lineTo(points[points.length - 1].x, points[points.length - 1].y);
  ctx.lineTo(points[points.length - 1].x, padTop + chartH);
  ctx.closePath();
  ctx.fillStyle = grad;
  ctx.fill();

  // Line
  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) {
    const cp = {
      x: (points[i - 1].x + points[i].x) / 2,
      y: (points[i - 1].y + points[i].y) / 2,
    };
    ctx.quadraticCurveTo(points[i - 1].x, points[i - 1].y, cp.x, cp.y);
  }
  ctx.lineTo(points[points.length - 1].x, points[points.length - 1].y);

  const lineGrad = ctx.createLinearGradient(0, 0, W, 0);
  lineGrad.addColorStop(0,   '#7c3aed');
  lineGrad.addColorStop(1,   '#3b82f6');
  ctx.strokeStyle = lineGrad;
  ctx.lineWidth   = 2.5;
  ctx.lineJoin    = 'round';
  ctx.stroke();

  // Dots
  points.forEach((pt, i) => {
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, 4, 0, Math.PI * 2);
    ctx.fillStyle   = '#fff';
    ctx.strokeStyle = '#7c3aed';
    ctx.lineWidth   = 2;
    ctx.fill();
    ctx.stroke();

    // X labels
    ctx.textAlign = 'center';
    ctx.fillStyle = labelColor;
    ctx.font      = '11px Inter, sans-serif';
    ctx.fillText(labels[i], pt.x, padTop + chartH + 20);
  });
}

// ===== CHART TABS =====
function initChartTabs() {
  document.querySelectorAll('.chart-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.chart-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeChartType = btn.dataset.type;
      drawChart(activeChartType);
    });
  });
}

// ===== TOP PRODUCTS =====
function renderTopProducts() {
  const list = document.getElementById('topProductsList');
  if (!list) return;

  const top = [...PRODUCTS_EXTENDED]
    .sort((a, b) => b.reviews - a.reviews)
    .slice(0, 5);

  const rankClass = ['rank-1','rank-2','rank-3','rank-n','rank-n'];

  list.innerHTML = top.map((p, i) => {
    const revenue = (p.reviews * p.price * 0.12).toFixed(0);
    return `
      <div class="top-product-item">
        <div class="top-product-rank ${rankClass[i]}">#${i + 1}</div>
        <img class="top-product-img" src="${p.image}" alt="${p.title}"
          onerror="this.src='https://via.placeholder.com/48?text=?'" loading="lazy" />
        <div class="top-product-info">
          <div class="top-product-name">${p.title}</div>
          <div class="top-product-sales">${p.reviews.toLocaleString()} sold</div>
        </div>
        <div class="top-product-revenue">$${Number(revenue).toLocaleString()}</div>
      </div>
    `;
  }).join('');
}

// ===== ORDERS TABLE =====
let ordersData = [...RECENT_ORDERS];

function renderOrdersTable(filter = 'all', search = '') {
  const tbody = document.getElementById('ordersTableBody');
  if (!tbody) return;

  let list = ordersData;
  if (filter !== 'all') list = list.filter(o => o.status === filter);
  if (search) {
    const q = search.toLowerCase();
    list = list.filter(o =>
      o.id.toLowerCase().includes(q) ||
      o.customer.toLowerCase().includes(q) ||
      o.product.toLowerCase().includes(q)
    );
  }

  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:2rem; color:var(--text-muted);">No orders found</td></tr>`;
    return;
  }

  tbody.innerHTML = list.map(o => `
    <tr>
      <td class="order-id">${o.id}</td>
      <td>${o.customer}</td>
      <td style="max-width:200px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${o.product}</td>
      <td>${new Date(o.date).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })}</td>
      <td class="order-amount">${formatPrice(o.amount)}</td>
      <td><span class="status-badge status-${o.status}">${capitalize(o.status)}</span></td>
      <td><button class="order-action-btn" onclick="viewOrder('${o.id}')">View</button></td>
    </tr>
  `).join('');
}

function capitalize(s) { return s[0].toUpperCase() + s.slice(1); }

function viewOrder(id) {
  showToast(`Viewing order ${id}`, 'info');
}

function initOrdersFilter() {
  const search = document.getElementById('ordersSearch');
  const filter = document.getElementById('ordersFilter');

  let debounce;
  search?.addEventListener('input', () => {
    clearTimeout(debounce);
    debounce = setTimeout(() => {
      renderOrdersTable(filter?.value || 'all', search.value);
    }, 250);
  });

  filter?.addEventListener('change', () => {
    renderOrdersTable(filter.value, search?.value || '');
  });
}

// ===== SIDEBAR COLLAPSE =====
function initSidebar() {
  const toggle  = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('dashSidebar');

  toggle?.addEventListener('click', () => {
    sidebar?.classList.toggle('collapsed');
    toggle.textContent = sidebar?.classList.contains('collapsed') ? '▶' : '◀';
  });

  // Mobile sidebar
  const dashHam = document.getElementById('dashHamburger');
  dashHam?.addEventListener('click', () => {
    sidebar?.classList.toggle('mobile-open');
  });

  document.addEventListener('click', (e) => {
    if (sidebar?.classList.contains('mobile-open') &&
        !sidebar.contains(e.target) &&
        !dashHam?.contains(e.target)) {
      sidebar.classList.remove('mobile-open');
    }
  });
}

// ===== NAV ITEMS =====
function initDashNav() {
  document.querySelectorAll('.dash-nav-item[data-section]').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      document.querySelectorAll('.dash-nav-item').forEach(n => n.classList.remove('active'));
      item.classList.add('active');
      const section = item.dataset.section;
      const titles  = {
        overview:  ['Overview',   'Welcome back, here\'s what\'s happening today.'],
        orders:    ['Orders',     'Manage and track all customer orders.'],
        products:  ['Products',   'Manage your product catalog.'],
        customers: ['Customers',  'View and manage customer accounts.'],
        analytics: ['Analytics',  'Deep dive into sales and performance metrics.'],
        settings:  ['Settings',   'Configure your store settings.'],
      };
      const [title, sub] = titles[section] || ['Dashboard', ''];
      document.getElementById('dashPageTitle').textContent = title;
      document.getElementById('dashPageSub').textContent   = sub;
    });
  });
}

// Redraw chart on resize
let resizeTimer;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => drawChart(activeChartType), 200);
});

// Redraw chart when theme changes
const darkToggle = document.getElementById('darkToggle');
darkToggle?.addEventListener('click', () => {
  setTimeout(() => drawChart(activeChartType), 100);
});

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  initStatCounters();
  renderTopProducts();
  renderOrdersTable();
  initOrdersFilter();
  initChartTabs();
  initSidebar();
  initDashNav();

  // Draw chart after layout is ready
  setTimeout(() => drawChart('sales'), 150);
});
