/* ===========================
   ShopEase - Products Page JS
   =========================== */

let currentFilters = {
  category: 'all',
  minPrice: 0,
  maxPrice: 1000,
  minRating: 0,
  search: '',
  sort: 'default',
};

// ===== FILTER & SORT =====
function getFilteredProducts() {
  let list = [...PRODUCTS_EXTENDED];
  const f  = currentFilters;

  if (f.category !== 'all') list = list.filter(p => p.category === f.category);
  if (f.search) {
    const q = f.search.toLowerCase();
    list = list.filter(p =>
      p.title.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      (p.tags || []).some(t => t.includes(q))
    );
  }
  list = list.filter(p => p.price >= f.minPrice && p.price <= f.maxPrice);
  list = list.filter(p => p.rating >= f.minRating);

  switch (f.sort) {
    case 'price-asc':  list.sort((a, b) => a.price - b.price);   break;
    case 'price-desc': list.sort((a, b) => b.price - a.price);   break;
    case 'rating':     list.sort((a, b) => b.rating - a.rating); break;
    case 'newest':     list.sort((a, b) => b.id - a.id);         break;
  }

  return list;
}

function renderProducts() {
  const grid       = document.getElementById('productsGrid');
  const empty      = document.getElementById('emptyState');
  const countEl    = document.getElementById('resultsCount');
  if (!grid) return;

  const list = getFilteredProducts();
  countEl && (countEl.textContent = `Showing ${list.length} product${list.length !== 1 ? 's' : ''}`);

  if (list.length === 0) {
    grid.innerHTML = '';
    empty?.classList.remove('hidden');
    return;
  }

  empty?.classList.add('hidden');

  // Skeleton → real with slight delay for animation effect
  grid.innerHTML = list.map(() => '<div class="skeleton skeleton-card"></div>').join('');

  setTimeout(() => {
    grid.innerHTML = list.map(p => buildProductCard(p)).join('');
  }, 400);
}

// ===== CATEGORY FILTERS (Sidebar) =====
function renderCategoryFilters() {
  const container = document.getElementById('categoryFilters');
  if (!container) return;

  const counts = {};
  CATEGORIES.forEach(c => {
    counts[c.id] = c.id === 'all'
      ? PRODUCTS_EXTENDED.length
      : PRODUCTS_EXTENDED.filter(p => p.category === c.id).length;
  });

  container.innerHTML = CATEGORIES.map(cat => `
    <button class="filter-chip ${currentFilters.category === cat.id ? 'active' : ''}"
      onclick="setCategory('${cat.id}')">
      <span>${cat.icon}</span>
      <span>${cat.name}</span>
      <span class="filter-chip-count">${counts[cat.id]}</span>
    </button>
  `).join('');
}

// ===== CATEGORY CHIPS (Top) =====
function renderCategoryChips() {
  const container = document.getElementById('categoryChips');
  if (!container) return;

  container.innerHTML = CATEGORIES.map(cat => `
    <button class="cat-chip ${currentFilters.category === cat.id ? 'active' : ''}"
      onclick="setCategory('${cat.id}')">
      ${cat.icon} ${cat.name}
    </button>
  `).join('');
}

function setCategory(catId) {
  currentFilters.category = catId;
  renderCategoryFilters();
  renderCategoryChips();
  renderProducts();
}

// ===== PRICE FILTER =====
function initPriceFilter() {
  const slider   = document.getElementById('priceSlider');
  const label    = document.getElementById('sliderLabel');
  const maxInput = document.getElementById('maxPrice');
  const minInput = document.getElementById('minPrice');

  if (!slider) return;

  slider.addEventListener('input', () => {
    const val = Number(slider.value);
    currentFilters.maxPrice = val;
    label.textContent = `$${val}`;
    maxInput && (maxInput.value = val);
    renderProducts();
  });

  maxInput?.addEventListener('input', () => {
    const val = Math.min(Number(maxInput.value) || 1000, 10000);
    currentFilters.maxPrice = val;
    slider.value = Math.min(val, 1000);
    renderProducts();
  });

  minInput?.addEventListener('input', () => {
    currentFilters.minPrice = Number(minInput.value) || 0;
    renderProducts();
  });
}

// ===== RATING FILTER =====
function initRatingFilter() {
  document.querySelectorAll('input[name="minRating"]').forEach(radio => {
    radio.addEventListener('change', () => {
      currentFilters.minRating = Number(radio.value);
      renderProducts();
    });
  });
}

// ===== SEARCH =====
function initSearch() {
  const input = document.getElementById('searchInput');
  if (!input) return;

  let debounceTimer;
  input.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      currentFilters.search = input.value.trim();
      renderProducts();
    }, 280);
  });
}

// ===== SORT =====
function initSort() {
  const select = document.getElementById('sortSelect');
  if (!select) return;
  select.addEventListener('change', () => {
    currentFilters.sort = select.value;
    renderProducts();
  });
}

// ===== CLEAR FILTERS =====
function clearAllFilters() {
  currentFilters = { category: 'all', minPrice: 0, maxPrice: 1000, minRating: 0, search: '', sort: 'default' };
  const searchInput = document.getElementById('searchInput');
  const minPrice    = document.getElementById('minPrice');
  const maxPrice    = document.getElementById('maxPrice');
  const priceSlider = document.getElementById('priceSlider');
  const sortSelect  = document.getElementById('sortSelect');
  const sliderLabel = document.getElementById('sliderLabel');

  if (searchInput)  searchInput.value  = '';
  if (minPrice)     minPrice.value     = '';
  if (maxPrice)     maxPrice.value     = '';
  if (priceSlider)  { priceSlider.value = 1000; }
  if (sliderLabel)  sliderLabel.textContent = '$1000';
  if (sortSelect)   sortSelect.value   = 'default';

  document.querySelectorAll('input[name="minRating"]')[0]?.click();
  renderCategoryFilters();
  renderCategoryChips();
  renderProducts();
}

document.getElementById('clearFilters')?.addEventListener('click', clearAllFilters);
document.getElementById('clearFiltersEmpty')?.addEventListener('click', clearAllFilters);

// ===== MOBILE FILTERS TOGGLE =====
function initMobileFilters() {
  const toggleBtn    = document.getElementById('toggleFiltersBtn');
  const sidebar      = document.getElementById('filtersSidebar');
  const applyBtn     = document.getElementById('applyFiltersBtn');

  toggleBtn?.addEventListener('click', () => {
    sidebar?.classList.toggle('open');
  });

  applyBtn?.addEventListener('click', () => {
    sidebar?.classList.remove('open');
  });

  // Close on outside click
  document.addEventListener('click', (e) => {
    if (sidebar?.classList.contains('open') &&
        !sidebar.contains(e.target) &&
        !toggleBtn?.contains(e.target)) {
      sidebar.classList.remove('open');
    }
  });
}

// ===== URL PARAMS =====
function applyURLParams() {
  const params = new URLSearchParams(window.location.search);
  const cat = params.get('category');
  if (cat) {
    currentFilters.category = cat;
  }
  const q = params.get('q');
  if (q) {
    currentFilters.search = q;
    const searchInput = document.getElementById('searchInput');
    if (searchInput) searchInput.value = q;
  }
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  applyURLParams();
  renderCategoryFilters();
  renderCategoryChips();
  initPriceFilter();
  initRatingFilter();
  initSearch();
  initSort();
  initMobileFilters();
  renderProducts();
});
