/* ===========================
   ShopEase - Home Page JS
   =========================== */

// ===== CATEGORIES =====
function renderCategories() {
  const grid = document.getElementById('categoriesGrid');
  if (!grid) return;

  grid.innerHTML = CATEGORIES.map(cat => `
    <a href="products.html?category=${cat.id}" class="category-card" data-cat="${cat.id}">
      <div class="category-icon">${cat.icon}</div>
      <span class="category-name">${cat.name}</span>
    </a>
  `).join('');
}

// ===== FEATURED PRODUCTS =====
function renderFeatured() {
  const grid = document.getElementById('featuredGrid');
  if (!grid) return;

  // Simulate loading
  setTimeout(() => {
    const featured = PRODUCTS_EXTENDED.filter(p => p.featured);
    grid.innerHTML = featured.map(p => buildProductCard(p)).join('');
  }, 800);
}

// ===== TRENDING =====
function renderTrending() {
  const grid = document.getElementById('trendingGrid');
  if (!grid) return;

  // Pick 6 products sorted by reviews
  const trending = [...PRODUCTS_EXTENDED]
    .sort((a, b) => b.reviews - a.reviews)
    .slice(0, 6);

  grid.innerHTML = trending.map((p, i) => `
    <a href="product-details.html?id=${p.id}" class="trending-item">
      <div class="trending-rank">#${i + 1}</div>
      <img class="trending-img" src="${p.image}" alt="${p.title}"
        onerror="this.src='https://via.placeholder.com/64?text=?'" loading="lazy" />
      <div class="trending-info">
        <div class="trending-title">${p.title}</div>
        <div class="trending-price">${formatPrice(p.price)}</div>
      </div>
      <button class="trending-add" onclick="handleAddToCart(event, ${p.id})" aria-label="Add to cart">+</button>
    </a>
  `).join('');
}

// ===== COUNTDOWN TIMER =====
function initCountdown() {
  // Target: 2 days 14 hours from now
  const target = new Date();
  target.setDate(target.getDate() + 2);
  target.setHours(target.getHours() + 14);
  target.setMinutes(target.getMinutes() + 37);

  function update() {
    const now  = Date.now();
    const diff = Math.max(0, target - now);

    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    const m = Math.floor((diff % 3600000)  / 60000);
    const s = Math.floor((diff % 60000)    / 1000);

    const pad = n => String(n).padStart(2, '0');
    const get = id => document.getElementById(id);

    if (get('cntDays'))  get('cntDays').textContent  = pad(d);
    if (get('cntHrs'))   get('cntHrs').textContent   = pad(h);
    if (get('cntMins'))  get('cntMins').textContent  = pad(m);
    if (get('cntSecs'))  get('cntSecs').textContent  = pad(s);
  }

  update();
  setInterval(update, 1000);
}

// ===== NEWSLETTER =====
function initNewsletter() {
  const form = document.getElementById('newsletterForm');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('newsletterEmail')?.value;
    if (email) {
      showToast(`🎉 Subscribed successfully! Welcome aboard.`, 'success');
      form.reset();
    }
  });
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  renderCategories();
  renderFeatured();
  renderTrending();
  initCountdown();
  initNewsletter();
});
