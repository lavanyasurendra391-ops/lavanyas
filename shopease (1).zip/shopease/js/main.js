/* ===========================
   ShopEase - Main JS (Shared)
   =========================== */

// ===== DARK MODE =====
const themeKey = 'shopease-theme';

function initTheme() {
  const saved = localStorage.getItem(themeKey) || 'light';
  document.documentElement.setAttribute('data-theme', saved);
  updateDarkToggle(saved);
}

function updateDarkToggle(theme) {
  const btn = document.getElementById('darkToggle');
  if (btn) btn.textContent = theme === 'dark' ? '☀️' : '🌙';
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem(themeKey, next);
  updateDarkToggle(next);
}

document.getElementById('darkToggle')?.addEventListener('click', toggleTheme);
initTheme();

// ===== CART =====
const cartKey = 'shopease-cart';

function getCart() {
  try { return JSON.parse(localStorage.getItem(cartKey)) || []; }
  catch { return []; }
}

function saveCart(cart) {
  localStorage.setItem(cartKey, JSON.stringify(cart));
  updateCartUI();
}

function addToCart(productId, qty = 1) {
  const product = PRODUCTS_EXTENDED.find(p => p.id === productId);
  if (!product) return;

  const cart = getCart();
  const existing = cart.find(i => i.id === productId);

  if (existing) {
    existing.qty = Math.min(existing.qty + qty, 99);
    showToast(`Updated quantity for "${product.title}"`, 'info');
  } else {
    cart.push({ id: productId, qty });
    showToast(`"${product.title}" added to cart! 🛒`, 'success');
  }
  saveCart(cart);
}

function removeFromCart(productId) {
  const cart = getCart().filter(i => i.id !== productId);
  saveCart(cart);
}

function updateCartQty(productId, qty) {
  const cart = getCart();
  const item = cart.find(i => i.id === productId);
  if (item) {
    if (qty < 1) { removeFromCart(productId); return; }
    item.qty = Math.min(qty, 99);
    saveCart(cart);
  }
}

function getCartTotal() {
  return getCart().reduce((sum, i) => {
    const p = PRODUCTS_EXTENDED.find(p => p.id === i.id);
    return sum + (p ? p.price * i.qty : 0);
  }, 0);
}

function getCartCount() {
  return getCart().reduce((sum, i) => sum + i.qty, 0);
}

function updateCartUI() {
  const count = getCartCount();
  document.querySelectorAll('#cartCount').forEach(el => {
    el.textContent = count;
    el.style.display = count > 0 ? 'flex' : 'none';
  });
}

updateCartUI();

// ===== WISHLIST =====
const wishKey = 'shopease-wishlist';

function getWishlist() {
  try { return JSON.parse(localStorage.getItem(wishKey)) || []; }
  catch { return []; }
}

function saveWishlist(list) {
  localStorage.setItem(wishKey, JSON.stringify(list));
  updateWishlistUI();
}

function toggleWishlist(productId) {
  const list = getWishlist();
  const product = PRODUCTS_EXTENDED.find(p => p.id === productId);
  const idx = list.indexOf(productId);
  if (idx === -1) {
    list.push(productId);
    showToast(`"${product?.title}" added to wishlist! 🤍`, 'success');
  } else {
    list.splice(idx, 1);
    showToast(`Removed from wishlist`, 'info');
  }
  saveWishlist(list);
  return idx === -1;
}

function isWishlisted(productId) {
  return getWishlist().includes(productId);
}

function updateWishlistUI() {
  const count = getWishlist().length;
  document.querySelectorAll('#wishlistCount').forEach(el => {
    el.textContent = count;
    el.style.display = count > 0 ? 'flex' : 'none';
  });
}

updateWishlistUI();

// ===== TOAST =====
function showToast(message, type = 'success', duration = 3500) {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${icons[type] || '✅'}</span>
    <span class="toast-message">${message}</span>
    <button class="toast-close" onclick="dismissToast(this.parentElement)">✕</button>
  `;
  container.appendChild(toast);

  setTimeout(() => dismissToast(toast), duration);
}

function dismissToast(toast) {
  if (!toast || toast.classList.contains('removing')) return;
  toast.classList.add('removing');
  setTimeout(() => toast.remove(), 300);
}

// ===== NAVBAR SCROLL =====
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (navbar) navbar.classList.toggle('scrolled', window.scrollY > 20);
  const scrollTop = document.getElementById('scrollTop');
  if (scrollTop) scrollTop.classList.toggle('visible', window.scrollY > 400);
}, { passive: true });

document.getElementById('scrollTop')?.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

// ===== HAMBURGER =====
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');

hamburger?.addEventListener('click', () => {
  mobileMenu?.classList.toggle('open');
});

document.addEventListener('click', (e) => {
  if (mobileMenu?.classList.contains('open') &&
      !mobileMenu.contains(e.target) &&
      !hamburger?.contains(e.target)) {
    mobileMenu.classList.remove('open');
  }
});

// ===== HELPERS =====
function renderStars(rating) {
  const full  = Math.floor(rating);
  const half  = rating % 1 >= 0.5 ? 1 : 0;
  const empty = 5 - full - half;
  return '★'.repeat(full) + (half ? '½' : '') + '☆'.repeat(empty);
}

function formatPrice(num) {
  return '$' + num.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function discountPercent(original, current) {
  return Math.round((1 - current / original) * 100);
}

function buildProductCard(product) {
  const wishlisted = isWishlisted(product.id);
  const badgeHTML  = product.badge
    ? `<span class="product-badge ${product.badge}">${product.badge.toUpperCase()}</span>` : '';
  const discountHTML = product.originalPrice
    ? `<span class="price-original">${formatPrice(product.originalPrice)}</span>` : '';

  return `
    <div class="product-card" data-id="${product.id}">
      <div class="product-image-wrap">
        ${badgeHTML}
        <button class="wishlist-btn ${wishlisted ? 'active' : ''}"
          onclick="handleWishlist(event, ${product.id})"
          aria-label="Toggle wishlist">
          ${wishlisted ? '❤️' : '🤍'}
        </button>
        <img src="${product.image}" alt="${product.title}" loading="lazy"
          onerror="this.src='https://via.placeholder.com/400x300?text=Product'" />
      </div>
      <div class="product-body">
        <div class="product-category">${product.category}</div>
        <div class="product-title">${product.title}</div>
        <div class="product-rating">
          <span class="stars">${renderStars(product.rating)}</span>
          <span class="rating-count">(${product.reviews.toLocaleString()})</span>
        </div>
        <div class="product-footer">
          <div class="product-price">
            <span class="price-current">${formatPrice(product.price)}</span>
            ${discountHTML}
          </div>
          <button class="btn btn-primary btn-sm"
            onclick="handleAddToCart(event, ${product.id})"
            aria-label="Add ${product.title} to cart">
            + Cart
          </button>
        </div>
      </div>
    </div>`;
}

function handleAddToCart(e, productId) {
  e.stopPropagation();
  addToCart(productId);
  // Animate button
  const btn = e.currentTarget;
  btn.textContent = '✓ Added';
  btn.style.background = 'var(--success)';
  setTimeout(() => {
    btn.textContent = '+ Cart';
    btn.style.background = '';
  }, 1400);
}

function handleWishlist(e, productId) {
  e.stopPropagation();
  const btn = e.currentTarget;
  const added = toggleWishlist(productId);
  btn.classList.toggle('active', added);
  btn.textContent = added ? '❤️' : '🤍';
}

// Navigate to product details
document.addEventListener('click', (e) => {
  const card = e.target.closest('.product-card');
  if (card && !e.target.closest('button')) {
    const id = card.dataset.id;
    window.location.href = `product-details.html?id=${id}`;
  }
});
