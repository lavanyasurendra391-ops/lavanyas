/* ===========================
   ShopEase - Product Details JS
   =========================== */

let currentProduct = null;
let currentQty     = 1;

// Fake thumbnail URLs (rotations of same image for demo)
function getThumbnails(product) {
  const base = product.image.replace(/\?.*/, '');
  return [
    product.image,
    base + '?w=400&h=300&fit=crop&flip=h',
    base + '?w=400&h=300&fit=crop&sat=-50',
    base + '?w=400&h=300&fit=crop&blur=1',
  ];
}

// Fake reviews
const REVIEW_NAMES  = ['Alex M.','Sarah K.','James L.','Priya S.','Tom W.','Mia R.'];
const REVIEW_TEXTS  = [
  'Absolutely love this product! Exceeded my expectations in every way.',
  'Great quality and fast shipping. Would definitely recommend to friends.',
  'Solid purchase. The build quality is excellent and it looks great.',
  'Perfect for everyday use. Very happy with this purchase overall.',
  'Exactly as described. Packaging was secure and arrived in perfect condition.',
  'One of the best purchases I\'ve made this year. Highly recommend!',
];

function generateReviews(rating, count) {
  const num = Math.min(6, Math.floor(count / 200) + 3);
  return Array.from({ length: num }, (_, i) => ({
    name:   REVIEW_NAMES[i % REVIEW_NAMES.length],
    rating: Math.min(5, Math.max(3, rating - 0.3 + Math.random() * 0.8)),
    text:   REVIEW_TEXTS[i % REVIEW_TEXTS.length],
    date:   new Date(Date.now() - i * 7 * 86400000).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
  }));
}

// ===== RENDER PRODUCT =====
function renderProduct(product) {
  currentProduct = product;

  // Hide skeleton, show content
  document.getElementById('productSkeleton').style.display = 'none';
  const content = document.getElementById('productContent');
  content.style.display = 'block';
  content.style.animation = 'none';
  void content.offsetWidth;
  content.style.animation = 'fadeSlideIn 0.4s ease';

  // Breadcrumb
  document.getElementById('breadcrumbProduct').textContent = product.title;
  document.title = `${product.title} – ShopEase`;

  // Main image
  const mainImg = document.getElementById('mainImage');
  mainImg.src = product.image;
  mainImg.alt = product.title;

  // Thumbnails
  const thumbs    = getThumbnails(product);
  const thumbStrip = document.getElementById('thumbnailStrip');
  thumbStrip.innerHTML = thumbs.map((src, i) => `
    <img class="thumb-img ${i === 0 ? 'active' : ''}" src="${src}" alt="View ${i + 1}"
      onclick="switchMainImage(this, '${src}')"
      onerror="this.style.display='none'" loading="lazy" />
  `).join('');

  // Wishlist button
  const wishBtn = document.getElementById('detailWishBtn');
  if (wishBtn) {
    const wishlisted = isWishlisted(product.id);
    wishBtn.textContent = wishlisted ? '❤️' : '🤍';
    wishBtn.classList.toggle('active', wishlisted);
    wishBtn.onclick = () => {
      const added = toggleWishlist(product.id);
      wishBtn.textContent = added ? '❤️' : '🤍';
      wishBtn.classList.toggle('active', added);
    };
  }

  // Badge
  const badgeEl = document.getElementById('detailBadge');
  if (product.badge) {
    badgeEl.textContent = product.badge.toUpperCase();
    badgeEl.className   = `product-badge ${product.badge}`;
    badgeEl.style.display = 'inline-block';
  }

  // Category & stock
  document.getElementById('detailCategory').textContent = product.category.toUpperCase();
  const stockEl = document.getElementById('detailStock');
  if (product.stock > 10) {
    stockEl.textContent = '✓ In Stock';
    stockEl.className   = 'badge badge-success';
  } else if (product.stock > 0) {
    stockEl.textContent = `Only ${product.stock} left!`;
    stockEl.className   = 'badge badge-warning';
  } else {
    stockEl.textContent = 'Out of Stock';
    stockEl.className   = 'badge badge-danger';
  }

  // Title
  document.getElementById('detailTitle').textContent = product.title;

  // Rating
  document.getElementById('detailStars').textContent   = renderStars(product.rating);
  document.getElementById('detailRatingVal').textContent = product.rating.toFixed(1);
  document.getElementById('detailReviews').textContent  = `(${product.reviews.toLocaleString()} reviews)`;

  // Price
  document.getElementById('detailPrice').textContent = formatPrice(product.price);
  if (product.originalPrice) {
    document.getElementById('detailOriginal').textContent = formatPrice(product.originalPrice);
    document.getElementById('detailDiscount').textContent =
      `${discountPercent(product.originalPrice, product.price)}% OFF`;
  }

  // Description
  document.getElementById('detailDesc').textContent = product.description;

  // Tags
  document.getElementById('detailTags').innerHTML = (product.tags || []).map(t =>
    `<span class="detail-tag">#${t}</span>`
  ).join('');

  // Qty controls
  initQtyControls(product);

  // Action buttons
  document.getElementById('addToCartBtn').onclick = () => {
    addToCart(product.id, currentQty);
  };
  document.getElementById('buyNowBtn').onclick = () => {
    addToCart(product.id, currentQty);
    window.location.href = 'cart.html';
  };

  // Related products
  renderRelated(product);

  // Reviews
  renderReviews(product);
}

function switchMainImage(thumbEl, src) {
  document.querySelectorAll('.thumb-img').forEach(t => t.classList.remove('active'));
  thumbEl.classList.add('active');
  const mainImg = document.getElementById('mainImage');
  mainImg.style.opacity = '0';
  setTimeout(() => {
    mainImg.src = src;
    mainImg.style.opacity = '1';
  }, 180);
}

function initQtyControls(product) {
  currentQty = 1;
  const input   = document.getElementById('qtyInput');
  const minusBtn = document.getElementById('qtyMinus');
  const plusBtn  = document.getElementById('qtyPlus');

  input.value = currentQty;

  minusBtn.onclick = () => {
    if (currentQty > 1) { currentQty--; input.value = currentQty; }
  };
  plusBtn.onclick = () => {
    if (currentQty < Math.min(product.stock, 99)) { currentQty++; input.value = currentQty; }
  };
  input.oninput = () => {
    let v = parseInt(input.value) || 1;
    v = Math.max(1, Math.min(v, Math.min(product.stock, 99)));
    currentQty = v;
    input.value = v;
  };
}

function renderRelated(product) {
  const grid = document.getElementById('relatedGrid');
  if (!grid) return;
  const related = PRODUCTS_EXTENDED
    .filter(p => p.id !== product.id && p.category === product.category)
    .slice(0, 4);
  grid.innerHTML = related.map(p => buildProductCard(p)).join('');
  if (!related.length) grid.parentElement.style.display = 'none';
}

function renderReviews(product) {
  const grid = document.getElementById('reviewsGrid');
  if (!grid) return;
  const reviews = generateReviews(product.rating, product.reviews);
  grid.innerHTML = reviews.map(r => `
    <div class="review-card">
      <div class="review-header">
        <div class="review-avatar">${r.name[0]}</div>
        <div class="review-author">
          <strong>${r.name}</strong>
          <span>${r.date}</span>
        </div>
      </div>
      <div class="review-stars">${'★'.repeat(Math.round(r.rating))}${'☆'.repeat(5 - Math.round(r.rating))}</div>
      <p class="review-text">${r.text}</p>
    </div>
  `).join('');
}

// ===== FADE-IN ANIMATION =====
const style = document.createElement('style');
style.textContent = `@keyframes fadeSlideIn { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }`;
document.head.appendChild(style);

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  const params  = new URLSearchParams(window.location.search);
  const id      = parseInt(params.get('id'));
  const product = PRODUCTS_EXTENDED.find(p => p.id === id);

  if (product) {
    setTimeout(() => renderProduct(product), 600);
  } else {
    // Fallback — show first product or redirect
    setTimeout(() => {
      renderProduct(PRODUCTS_EXTENDED[0]);
    }, 600);
  }
});
